//[app Javascript]


$(function () {
    "use strict";    
		
	 // chat app scrolling
  
	  $('#chat-app, #chat-contact').slimScroll({
		height: '600px'
	  });	
	
  }); // End of use strict