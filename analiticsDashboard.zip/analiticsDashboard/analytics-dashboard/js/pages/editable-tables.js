//[Javascript]



$(function () {
    "use strict";   
		
	  $('#mainTable1').editableTableWidget().numericInputExample().find('td:first').focus();
		$('#mainTable2').editableTableWidget().numericInputExample().find('td:first').focus();
        $('#example8').editableTableWidget().numericInputExample().find('td:first').focus();
	
  }); // End of use strict